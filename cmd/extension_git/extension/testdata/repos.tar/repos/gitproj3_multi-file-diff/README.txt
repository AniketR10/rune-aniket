Two files: one with partially staged changes and another one with many unstaged changes.
