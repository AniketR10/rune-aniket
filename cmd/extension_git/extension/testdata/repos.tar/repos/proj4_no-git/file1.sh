#!/usr/bin/env bash

echo "hello from file 1"
