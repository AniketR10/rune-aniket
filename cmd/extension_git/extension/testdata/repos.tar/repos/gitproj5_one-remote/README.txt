Project with a git.unstable.build remote.
