Clean. No unstaged nor uncommitted changes.
