Project with two remotes: a private one in origin and a github fork.
